/*
  Smart Office Monitoring System
  Wokwi Simulation
  3 Lights + 2 Fans (represented by LEDs)

  GPIO18 -> Light 1
  GPIO19 -> Light 2
  GPIO21 -> Light 3
  GPIO22 -> Fan 1
  GPIO23 -> Fan 2
*/

const int light1 = 18;
const int light2 = 19;
const int light3 = 21;

const int fan1 = 22;
const int fan2 = 23;

bool deviceState[5];

unsigned long previousMillis = 0;
const unsigned long interval = 8000;   // Change every 8 seconds

void setup() {

  Serial.begin(115200);

  pinMode(light1, OUTPUT);
  pinMode(light2, OUTPUT);
  pinMode(light3, OUTPUT);
  pinMode(fan1, OUTPUT);
  pinMode(fan2, OUTPUT);

  randomSeed(micros());

  Serial.println("--------------------------------");
  Serial.println(" SMART OFFICE DEVICE SIMULATOR ");
  Serial.println("--------------------------------");
}

void loop() {

  if (millis() - previousMillis >= interval) {

    previousMillis = millis();

    // Random ON/OFF for each device
    for (int i = 0; i < 5; i++) {
      deviceState[i] = random(2);
    }

    digitalWrite(light1, deviceState[0]);
    digitalWrite(light2, deviceState[1]);
    digitalWrite(light3, deviceState[2]);
    digitalWrite(fan1, deviceState[3]);
    digitalWrite(fan2, deviceState[4]);

    printStatus();
  }
}

void printStatus() {

  Serial.println();
  Serial.println("========= DEVICE STATUS =========");

  Serial.print("Light 1 : ");
  Serial.println(deviceState[0] ? "ON" : "OFF");

  Serial.print("Light 2 : ");
  Serial.println(deviceState[1] ? "ON" : "OFF");

  Serial.print("Light 3 : ");
  Serial.println(deviceState[2] ? "ON" : "OFF");

  Serial.print("Fan 1   : ");
  Serial.println(deviceState[3] ? "ON" : "OFF");

  Serial.print("Fan 2   : ");
  Serial.println(deviceState[4] ? "ON" : "OFF");

  int totalPower = 0;

  if (deviceState[0]) totalPower += 15;
  if (deviceState[1]) totalPower += 15;
  if (deviceState[2]) totalPower += 15;

  if (deviceState[3]) totalPower += 60;
  if (deviceState[4]) totalPower += 60;

  Serial.println("-------------------------------");
  Serial.print("Current Power: ");
  Serial.print(totalPower);
  Serial.println(" W");

  Serial.println("-------------------------------");
}